﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace SF2022UserLib.Tests
{
    [TestClass]
    public class CalculationsTests
    {
        [TestMethod]
        public void AvailablePeriods_NullStartTimes() // получение null в качестве массива начальных времен
        {
            var calculations = new Calculations();
            TimeSpan[] startTimes = null;
            int[] durations = { 30, 45 };

            Assert.ThrowsException<ArgumentNullException>(() =>
            {
                calculations.AvailablePeriods(startTimes, durations, TimeSpan.FromHours(9), TimeSpan.FromHours(17), 60);
            });
        }

        [TestMethod]
        public void AvailablePeriods_NullDurations() // получение null в качестве массива длительностей
        {
            var calculations = new Calculations();
            TimeSpan[] startTimes = { TimeSpan.FromHours(9), TimeSpan.FromHours(10) };
            int[] durations = null;

            Assert.ThrowsException<ArgumentNullException>(() =>
            {
                calculations.AvailablePeriods(startTimes, durations, TimeSpan.FromHours(9), TimeSpan.FromHours(17), 60);
            });
        }

        [TestMethod]
        public void AvailablePeriods_ArraysLengthMismatch() // обработка массивов различной длины
        {
            var calculations = new Calculations();
            TimeSpan[] startTimes = { TimeSpan.FromHours(9), TimeSpan.FromHours(10) };
            int[] durations = { 30 };

            Assert.ThrowsException<ArgumentException>(() =>
            {
                calculations.AvailablePeriods(startTimes, durations, TimeSpan.FromHours(9), TimeSpan.FromHours(17), 60);
            });
        }

        [TestMethod]
        public void AvailablePeriods_NegativeConsultationTime() // отрицательное значение времени
        {
            var calculations = new Calculations();
            TimeSpan[] startTimes = { TimeSpan.FromHours(9), TimeSpan.FromHours(10) };
            int[] durations = { 30, 45 };

            Assert.ThrowsException<ArgumentException>(() =>
            {
                calculations.AvailablePeriods(startTimes, durations, TimeSpan.FromHours(9), TimeSpan.FromHours(17), -30);
            });
        }

        [TestMethod]
        public void AvailablePeriods_EndBeforeStart() // начала рабочего дня больше времени окончания
        {
            var calculations = new Calculations();
            TimeSpan[] startTimes = { TimeSpan.FromHours(15) };
            int[] durations = { 30 };

            Assert.ThrowsException<ArgumentOutOfRangeException>(() =>
            {
                calculations.AvailablePeriods(startTimes, durations, TimeSpan.FromHours(17), TimeSpan.FromHours(9), 60);
            });
        }

        [TestMethod]
        public void AvailablePeriods_OutsideWorkingHours() // консультация начинается вне работы
        {
            var calculations = new Calculations();
            TimeSpan[] startTimes = { TimeSpan.FromHours(2) };
            int[] durations = { 30 };

            Assert.ThrowsException<ArgumentOutOfRangeException>(() =>
            {
                calculations.AvailablePeriods(startTimes, durations, TimeSpan.FromHours(9), TimeSpan.FromHours(17), 60);
            });
        }

        [TestMethod]
        public void AvailablePeriods_NoExistingConsultations() // свободно + нет запланированных консультаций
        {
            var calculations = new Calculations();
            TimeSpan[] startTimes = { };
            int[] durations = { };

            var result = calculations.AvailablePeriods(startTimes, durations, TimeSpan.FromHours(9), TimeSpan.FromHours(17), 60);

            Assert.AreEqual(8, result.Length);
        }

        [TestMethod]
        public void AvailablePeriods_SingleConsultation() // одна консультация + свободно
        {
            var calculations = new Calculations();
            TimeSpan[] startTimes = { TimeSpan.FromHours(9) };
            int[] durations = { 30 };

            var result = calculations.AvailablePeriods(startTimes, durations, TimeSpan.FromHours(9), TimeSpan.FromHours(17), 60);

            Assert.AreEqual(7, result.Length);
        }

        [TestMethod]
        public void AvailablePeriods_MultipleConsultations() // свободно + запл. консультации
        {
            var calculations = new Calculations();
            TimeSpan[] startTimes = { TimeSpan.FromHours(9), TimeSpan.FromHours(11), TimeSpan.FromHours(13) };
            int[] durations = { 30, 45, 60 };

            var result = calculations.AvailablePeriods(startTimes, durations, TimeSpan.FromHours(9), TimeSpan.FromHours(17), 60);

            Assert.AreEqual(5, result.Length);
        }

        [TestMethod]
        public void Format_TimeSpan_ReturnsCorrectFormat() // TimeSpan в hh mm
        {
            TimeSpan ts = new TimeSpan(0, 0, 0);
            string formattedTime = Calculations.Format(ts);
            Assert.AreEqual("00:00", formattedTime);
        }
    }
}
